# v0.3.7 / v0.3.8 available-donor comparison

Validated configurations: 12/12.

Each configuration runs 0.3.7, 0.3.8, 0.3.8, 0.3.7 sequentially on one runner.
Each observation uses a fresh process and the same dependencies and inputs.

Delta = 100 * (v0.3.8 mean / v0.3.7 mean - 1). Negative means less time or memory.
Spread = 100 * (maximum - minimum) / mean within a release.
Two observations per release are a pilot, not a statistical significance claim.

Peak RSS is the process high-water mark read immediately after transform, before validation.
It includes imports, data generation, small warmup and fit; it is not transform-only memory.
This pilot covers mean aggregation, one seed, 128 queries, 12 features and k=5.
The sparse and exhaustion cases are targeted synthetic workloads, not representative averages.

| Case | Donors | Threads | 0.3.7 transform s | 0.3.8 transform s | Time delta % | 0.3.7 spread % | 0.3.8 spread % | 0.3.7 peak MiB | 0.3.8 peak MiB | Memory delta % |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| ordinary | 16384 | 1 | 0.0598 | 0.0549 | -8.21 | 21.29 | 0.01 | 187.8 | 187.5 | -0.14 |
| ordinary | 16384 | 2 | 0.0511 | 0.0521 | +2.10 | 1.19 | 1.25 | 189.7 | 189.7 | -0.03 |
| ordinary | 65536 | 1 | 0.2207 | 0.2233 | +1.19 | 0.96 | 0.99 | 358.5 | 358.4 | -0.04 |
| ordinary | 65536 | 2 | 0.2058 | 0.2043 | -0.68 | 0.58 | 0.20 | 360.7 | 360.8 | +0.04 |
| mixed_sparse | 16384 | 1 | 1.2939 | 0.1219 | -90.58 | 0.35 | 0.08 | 275.5 | 187.7 | -31.86 |
| mixed_sparse | 16384 | 2 | 0.9057 | 0.0977 | -89.21 | 0.03 | 6.51 | 277.5 | 189.9 | -31.57 |
| mixed_sparse | 65536 | 1 | 6.1956 | 0.5535 | -91.07 | 0.12 | 0.21 | 672.5 | 358.7 | -46.66 |
| mixed_sparse | 65536 | 2 | 4.3500 | 0.3943 | -90.93 | 1.22 | 0.12 | 674.5 | 360.9 | -46.50 |
| finite_exhaustion | 16384 | 1 | 0.5565 | 0.0590 | -89.40 | 0.75 | 1.48 | 259.8 | 187.7 | -27.74 |
| finite_exhaustion | 16384 | 2 | 0.5158 | 0.0578 | -88.79 | 3.88 | 4.39 | 261.8 | 189.8 | -27.47 |
| finite_exhaustion | 65536 | 1 | 2.6296 | 0.2366 | -91.00 | 0.49 | 1.82 | 574.7 | 358.6 | -37.60 |
| finite_exhaustion | 65536 | 2 | 2.2626 | 0.2200 | -90.28 | 0.70 | 0.63 | 577.0 | 360.6 | -37.51 |

Fit and total time, memory spread, raw observations and output differences are in the artifact.
